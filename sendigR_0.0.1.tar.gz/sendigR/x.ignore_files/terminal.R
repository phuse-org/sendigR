devtools::load_all()
db <- initEnvironment(dbType = "sqlite", dbPath 
    = "tests/data/test_db.db")
execSendDashboard(db)
